BEFORE & AFTER LIBRARY
======================
Built 17 September 2026 from the photos in this folder.

WHAT IS HERE
------------
63 matched before/after pairs covering 28 procedures and 55 patients.

Every image is cropped to exactly 1600 x 1200 pixels (4:3 landscape), JPEG
quality 90. Within each pair the before and after are framed to match, so
they line up when the reveal slider wipes between them.

FOLDER LAYOUT
-------------
  <Procedure>/<Patient>/before.jpg
                        after.jpg
                        caption.txt

Where a patient has more than one angle the files are suffixed, e.g.
  before-front.jpg / after-front.jpg
  before-profile.jpg / after-profile.jpg
Each of those is a complete pair - every before has its matching after.

caption.txt holds the short line to sit under the slider. Captions never
name the patient. Patient names appear only in folder titles, so drop the
folder name before publishing anything.

index.csv lists every pair, its caption, and which original file it came
from, so you can trace anything back.

CONTENTS
--------
  01 ACP Electrolysis                                  3 patients, 3 pairs
  02 AFT Laser - Age Spots                             2 patients, 3 pairs
  03 Alma Laser - Pigmentation                         2 patients, 2 pairs
  04 Alma Laser - Thread Veins                         1 patient, 1 pair
  05 iPixel Laser Resurfacing                          4 patients, 4 pairs
  06 Biodermogenesi                                    3 patients, 3 pairs
  07 Dye-VL Laser - Rosacea & Flushing                 3 patients, 4 pairs
  08 Dermal Filler - 8 Point Lift                      1 patient, 1 pair
  08 Dermal Filler - Acne Scarring                     1 patient, 1 pair
  08 Dermal Filler - Cheek Enhancement                 1 patient, 1 pair
  08 Dermal Filler - Jaw Enhancement                   1 patient, 2 pairs
  08 Dermal Filler - Jaw Reduction                     1 patient, 1 pair
  08 Dermal Filler - Jowl                              1 patient, 1 pair
  08 Dermal Filler - Lip Enhancement                   2 patients, 2 pairs
  09 Non-Surgical Rhinoplasty                          3 patients, 3 pairs
  10 Eye Rejuvenation                                  1 patient, 1 pair
  11 Kleresca Light Therapy                            3 patients, 3 pairs
  12 Laser Hair Removal                                1 patient, 1 pair
  13 PRP - Skin Rejuvenation                           1 patient, 1 pair
  14 Pore Refinement                                   1 patient, 1 pair
  15 Laser - Pigmentation                              2 patients, 2 pairs
  16 Rosacea & Facial Flushing                         1 patient, 1 pair
  17 Skin Peels                                        2 patients, 2 pairs
  18 Tattoo Removal                                    5 patients, 5 pairs
  19 Botox                                             4 patients, 8 pairs
  20 Microneedling                                     3 patients, 3 pairs
  21 Acne Scarring                                     1 patient, 2 pairs
  22 Nano Plasma - Non-Surgical Blepharoplasty         1 patient, 1 pair

_Review - unpaired & flagged
----------------------------
69 files that are not part of a matched pair - afters with no before,
duplicates, treatment-in-progress shots, manufacturer marketing images, and
three .HEIC files this tool could not open. They are copied at their original
size and resolution with a README.txt explaining each one. Nothing was thrown
away.

WORTH KNOWING BEFORE YOU PUBLISH
--------------------------------
* Some pairs are a best guess: neither file was labelled before or after, so
  the order was inferred from the photos. Those carry a note at the bottom of
  their caption.txt and are marked in index.csv. Please confirm them.
* The Candela Profound images are manufacturer marketing material credited to
  other clinicians - they are in _Review, not in the library.
* Two panoramic source photos (pore refinement, forehead lines) are much wider
  than 4:3. Rather than cut the sides off, they sit on a soft blurred
  background inside the 1600 x 1200 frame.
* The .pptx decks in the parent folder were not opened. If they hold photos
  that are not loose in these folders, say the word and they can be pulled out.
* _work and _to_delete in the parent folder are leftovers from this build and
  can be deleted.
